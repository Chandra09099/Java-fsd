package oops;

public class Inheri {
	public static void main(String[] args) {
		
		A a=new A();
		a.child();
		a.parent();

	}

}
class A extends B
{
	void child()
	{
		System.out.println("Iam child");
	}
}
class B
{
	void parent()
	{
		System.out.println("iam a parent");
	}
}


