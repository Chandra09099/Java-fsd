package oops;

public class Encap1 {
    public static void main(String[] args) {
        Employee c1 = new Employee();
        c1.setCid(121);
        c1.setCname("manoj");
        c1.setAge(21);

        Employee c2 = new Employee(101, "lathik", 23);

        System.out.println("Customer info");
        System.out.println("CId is " + c1.getCid());
        System.out.println("CName is " + c1.getCname());
        System.out.println("CAge is " + c1.getAge());

        System.out.println("Customer info");
        System.out.println("CId is " + c2.getCid());
        System.out.println("CName is " + c2.getCname());
        System.out.println("CAge is " + c2.getAge());
    }
}



