package oops;

public class OverRiding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		overload o=new overload();
		o.add();
		o.add(2);
		o.add(1, 3);
		o.add('c',"d");
		o.add(10,20);

	}

}
class OverRide
{
	void add()
	{
		System.out.println("iam in void");
	}
	void add(int a)
	{
		System.out.println(a);
	}
	void add(int a,int b)
	{
		System.out.println(a+b);
	}
	void add(char a,String b)
	{
		System.out.println(a+b);
	}
}
