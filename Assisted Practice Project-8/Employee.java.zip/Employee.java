package oops;

public class Employee {
    private int cid;
    private String cname;
    private int age;

    // Default constructor
    public Employee() {
    }

    // Parameterized constructor
    public Employee(int cid, String cname, int age) {
        this.cid = cid;
        this.cname = cname;
        this.age = age;
    }

    // Getter and Setter methods for cid
    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    // Getter and Setter methods for cname
    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    // Getter and Setter methods for age
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
