package diam;

public class DP {

    interface First {
        default void show() {
            System.out.println("I am a Default First");
        }
    }

    interface Second {
        default void show() {
            System.out.println("I am a Default Second");
        }
    }

    public class Main implements First, Second {
        public void show() {
            First.super.show();
            Second.super.show();
        }
    }

    public static void main(String args[]) {
        DP dp = new DP();
        DP.Main o = dp.new Main(); // Instantiate Main within an instance of DP
        o.show();
    }
}
