package sync;
import java.io.*; 
import java.util.*;

public class send {
    public void send(String msg) {
        // send implementation
    }
}
