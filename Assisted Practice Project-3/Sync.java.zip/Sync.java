package sync;

public class Sync {
    public static void main(String args[]) {
        Send snd = new Send();
        ThreadedSend1 S1 = new ThreadedSend1();
        ThreadedSend1 S2 = new ThreadedSend1();

        S1.start();
        S2.start();

        try {
            S1.join();
            S2.join();
        } catch(Exception e) {
            System.out.println("Interrupted");
        }
    }

    static class Send {
        // Send class implementation
    }

    static class ThreadedSend1 extends Thread {
        // ThreadedSend1 class implementation
    }
}
