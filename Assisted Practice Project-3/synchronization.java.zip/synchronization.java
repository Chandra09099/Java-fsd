package sync;
import java.io.*; 
import java.util.*;

import sync.Sync.Send;
import sync.Sync.ThreadedSend1;

public class synchronization {
	 
	class Send
	{ 
	    public void send(String msg) 
	    { 
	        System.out.println("Sending the \t"  + msg ); 
	        try
	        { 
	            Thread.sleep(1000); 
	        } 
	        catch (Exception e) 
	        { 
	            System.out.println("Thread  interrupted."); 
	        } 
	        System.out.println("\n" + msg + "Sent"); 
	    } 
	} 
	class ThreadedSend1 extends Thread 
	{ 
	    private String msg; 
	    private Thread t; 
	    Send  sender; 
	    ThreadedSend1(String m,  Send obj) 
	    { 
	        msg = m; 
	        sender = obj; 
	    } 
	  
	    public void run() 
	    {  
	        synchronized(sender) 
	        { 
	            sender.send(msg); 
	        } 
	    } 
	} 
	class SyncDemo 
	{ 
	    public static void main(String args[]) 
	    { 
	    	Send snd = new Send();
	        ThreadedSend1 S1 = new ThreadedSend1();
	        ThreadedSend1 S2 = new ThreadedSend1();

	        S1.start();
	        S2.start();

	        try {
	            S1.join();
	            S2.join();
	        } catch(Exception e) {
	            System.out.println("Interrupted");
	        }
	    }

	    static class Send {
	        // Send class implementation
	    }

	    static class ThreadedSend1 extends Thread {
	        // ThreadedSend1 class implementation
	    }
	}
}

