package sync;
import java.io.*; 
import java.util.*;

import sync.synchronization.Send;

public class ThreadSend1 extends Thread {
    private String msg;
    private Send sender;

    public ThreadSend1(String m, Send obj) {
        msg = m;
        sender = obj;
    }

    public void run() {
        synchronized(sender) {
            sender.send(msg);
        }
    }
}
