package method_calling;

public class methodCall {
	static void staticMethod() {
        System.out.println("This is a static method.");
    }

    
    void instanceMethod() {
        System.out.println("This is an instance method.");
    }

    
    void methodWithParameters(int x, int y) {
        System.out.println("Sum of " + x + " and " + y + " is: " + (x + y));
    }

  
    void methodOverloading() {
        System.out.println("Method without parameters.");
    }

    void methodOverloading(int num) {
        System.out.println("Method with parameter: " + num);
    }

    void methodOverloading(String str) {
        System.out.println("Method with parameter: " + str);
    }

  
    void overriddenMethod() {
        System.out.println("This is the original method.");
    }
}

class Subclass extends methodCall {
   
   
    void overriddenMethod() {
        System.out.println("This is the overridden method in the subclass.");
    }
}
	


