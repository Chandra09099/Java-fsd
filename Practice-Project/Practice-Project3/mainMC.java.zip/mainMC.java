package method_calling;

public class mainMC {
	public static void main(String[] args) {
		
	       
		methodCall.staticMethod();

       
		methodCall instance = new methodCall();

        
        instance.instanceMethod();

        
        instance.methodWithParameters(6, 8);

        
        instance.methodOverloading();
        instance.methodOverloading(36);
        instance.methodOverloading("Hello, Method Overloading!");

        
        methodCall originalObject = new methodCall();
        originalObject.overriddenMethod();

        Subclass subclassObject = new Subclass();
        subclassObject.overriddenMethod();
    }
	

}
