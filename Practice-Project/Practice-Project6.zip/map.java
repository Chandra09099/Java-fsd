package mapsEx;

import java.util.*;


public class map {

	public static void main(String[] args) {
		Map<Integer,String> map=new HashMap<Integer,String>();  
		  map.put(1,"midhuna");  
		  map.put(2,"priya");  
		  map.put(3,"ravi");  
		for(Map.Entry m:map.entrySet()){  
		   System.out.println(m.getKey()+" "+m.getValue());  
		  } 
		  System.out.println(map);
		  map.put(new Integer(1), "pandit"); //inserting elements
	      map.put(new Integer(2), "rohit"); 
	      System.out.println(" Map= " + map); 
	      map.remove(new Integer(1)); 
	      System.out.println(map);

	}

}
