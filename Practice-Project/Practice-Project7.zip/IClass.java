package InClass;

public class IClass {
    private int outerVariable = 15;

    // Inner class
    class Inner {
        void display() {
            System.out.println("Inner class method: " + outerVariable);
        }
    }

    // Method in the outer class using the inner class
    public void outerMethod() {
        Inner innerObj = new Inner();
        innerObj.display();
    }

    public static void main(String[] args) {
        IClass outerObj = new IClass();
        outerObj.outerMethod();
    }
}

