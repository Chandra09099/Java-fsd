package package_1;

public class MainM {
	public static void main(String[] args) {
		
        
        modifiers example = new modifiers();
        
        
        System.out.println("Public field: " + example.publicField);
        System.out.println("Protected field: " + example.protectedField);
        System.out.println("Default field: " + example.defaultField);
        System.out.println("Private field: " + example.privateField);

        
        example.protectedMethod();
        example.defaultMethod();
        example.privateMethod();
    }

	    
	   

}
