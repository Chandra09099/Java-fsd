package package_1;

public class modifiers {
	
	public int publicField = 5;

	    
	    protected int protectedField = 10;

	    
	    int defaultField = 15;

	    
	    int privateField = 20;

	 
	    public modifiers() {
	        System.out.println("Public constructor called");
	    }

	    
	    protected void protectedMethod() {
	        System.out.println("Protected method called");
	    }

	   
	    void defaultMethod() {
	        System.out.println("Default method called");
	    }

	    
	    void privateMethod() {
	        System.out.println("Private method called");
	    }

}


