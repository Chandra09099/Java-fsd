package Arrays;

public class Arrays {

	public static void main(String[] args) {
		int b[]= {10,20,30,40};
		for(int j=0;j<b.length;j++) {
			System.out.println(b[j]);
		}
		System.out.println(b);
		int a[]=new int[4];// single dimensional  array declaration and instantiation  
		a[0]=5;
		a[1]=10;  
		a[2]=15;  
		a[3]=20;  
		 
		for(int i=0;i<a.length;i++) {
		
			System.out.println(a[i]);  
		}

		System.out.println("clone of an array");
		int carr[]=a.clone();
	
	for(int i:carr)  {
		
	
			System.out.println(i);  
	}
		int arr[][]={{1,2,3},{2,4,5},{4,4,5}};  //multidimensional array
		
		for(int l=0;l<3;l++){  
		 for(int j=0;j<3;j++){  
		   System.out.print(arr[l][j]+" ");  
		 }  
System.out.println();
		}

	}

}
