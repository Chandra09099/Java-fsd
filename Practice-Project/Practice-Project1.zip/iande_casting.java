package casting;

public class iande_casting {

	public static void main(String[] args) {
		
		 int numInt = 10;
	        double numFloat = numInt; //  (implicit)

	        System.out.println("Implicit Casting:");
	        System.out.println("int value: " + numInt);
	        System.out.println(" Float value after implicit casting: " + numFloat);

	        // Explicit casting (narrowing)
	        numFloat = 10.5f;
	        int newInt = (int) numFloat; // (explicit)

	        System.out.println("\nExplicit Casting:");
	        System.out.println("Float value: " + numFloat);
	        System.out.println("int value after explicit casting: " + newInt);
	    }

}

