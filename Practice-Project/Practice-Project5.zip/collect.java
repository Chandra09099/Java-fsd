package collection;
import java.util.* ;

public class collect {
	public static void main(String[] args) {
		
		List<String> list= new ArrayList<String>();
		Vector<Integer> v= new Vector<Integer>();
		list.add("sai");
		list.add("shaik");
		v.addElement(1);
		v.addElement(2);
		System.out.println(list);
		System.out.println(v);
		Stack<String> stack = new Stack<String>();  
		stack.push("Edward");  
		stack.push("Hari");
		stack.push("Midhuna");
		stack.pop();  
		Iterator<String> itr=stack.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());  
		}
			}
	

}
