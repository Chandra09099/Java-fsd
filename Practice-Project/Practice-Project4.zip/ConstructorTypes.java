package ConstructorTY;

public class ConstructorTypes {
	ConstructorTypes() //default constructor
	{
	 System.out.println("this is default constructor");
	}
	ConstructorTypes(int a,int b) // parameterized constructor
	{ 
		int c=a+b;
	 System.out.println(c);
		}
	public static void main (String args[]) {
	ConstructorTypes x =new ConstructorTypes();
	ConstructorTypes y =new ConstructorTypes(6,8);
	}

	

}
