package thread;

public class MyThread extends Thread {

    // Overriding run() method to print a message when the thread starts
    public void run() {
        System.out.println("Thread Started");
    }

    public static void main(String[] args) {
        MyThread t1 = new MyThread();
        MyThread t2 = new MyThread();

        t1.start();
        t2.start();
    }
}

	