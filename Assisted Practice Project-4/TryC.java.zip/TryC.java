package tcollect;

import java.util.Scanner;

public class TryC {
	
    public static void main(String[] args) {
        
    	Scanner scanner = new Scanner(System.in);

        try {
          
        	System.out.print("Enter a number: ");
            int number = Integer.parseInt(scanner.nextLine());

            int result = 10 / number;
           
            System.out.println("Result: " + result);
        } 
        catch (NumberFormatException e) {

       System.out.println("Invalid input! Please enter a valid number.");
       
        } 
        catch (ArithmeticException e) {
            
        	System.out.println("Cannot divide by zero. Please enter a non-zero number.");
        } 
        
        catch (Exception e) {
            
        	System.out.println("An unexpected error occurred: " + e.getMessage());
        } 
        
        
       finally {
            
    	   System.out.println("This block always executes, regardless of whether an exception occurred or not.");
            
    	   scanner.close();
        }
    }
}
