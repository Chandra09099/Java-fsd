package thro;

public class throwD {

	
        void Show() throws ArithmeticException
        {
            int a=100,b=0,res;
            res = a / b;
            System.out.print("\n\tThe result is : " + res);
        }
         public static void main(String[] args)
        {
         throwD T = new throwD();
             try
            {
                T.Show();
            }
            catch(ArithmeticException e)
            {
                System.out.print("\n\tError : " + e.getMessage());
            }

        }
}