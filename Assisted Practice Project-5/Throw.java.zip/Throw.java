package thro;

public class Throw {

	
	        public static void main(String[] args)
	        {

	            int a=100,b=0,res;

	            try
	            {
	                if(b==0)        
	                    throw(new ArithmeticException("Can't divide by zero."));
	                else
	                {
	                    res = a / b;
	                    System.out.print("\n\tThe result is : " + res);
	                }
	            }
	            catch(ArithmeticException E)
	            {
	                System.out.print("\n\tError : " + E.getMessage());
	            }

	            System.out.print("\n\tEnd of program.");
	        }
	    


	}
