package thro;

public class throw1D {
    void show() throws ArithmeticException {
        int a = 100, b = 0, res;
        res = a / b;
        System.out.print("\n\tThe result is : " + res);
    }

    public static void main(String[] args) {
        throw1D t = new throw1D();
        try {
            t.show();
        } catch (ArithmeticException e) {
            System.out.print("\n\tError : " + e.getMessage());
        } finally {
            // Clean-up or finalization code if needed
            System.out.print("\nI am in finally.");
        }
    }
}
